<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Con_tabungan extends Controller
{
    public function index()
    {
    	$active = "active";
        $title ="Kategori Buku";
        $judul_navbar = "Daftar Kategori";
        $tabungan = \App\Rekening::all();
        return view('sibasah.tabungan.tabungan',compact('tabungan','title','judul_navbar','active'));
    }
}
