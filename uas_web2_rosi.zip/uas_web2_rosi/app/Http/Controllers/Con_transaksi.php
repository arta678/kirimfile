<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Con_transaksi extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $active = "active";
        $title ="Kategori Buku";
        $judul_navbar = "Daftar Kategori";
        $sampah = \App\Sampah::all();
        $nasabah = \App\Nasabah::all();
        $transaksi = \App\Transaksi::all();
        return view('sibasah.transaksi.transaksi',compact('transaksi','nasabah','sampah','title','judul_navbar','active'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $request->validate([
        //     'nama' => 'required',
        //     'hp' => 'required',
        //     'alamat' => 'required',
        // ]);

        $transaksi = new \App\Transaksi;
        $sampah = new \App\Sampah;

        $transaksi->id_nasabah = $request->id_nasabah;
        $transaksi->id_sampah = $request->id_sampah;
        $transaksi->id_rekening = $request->id_nasabah;
        $transaksi->berat_sampah = $request->berat_sampah;


        $saldo=$request->berat_sampah*$sampah->harga;

        $transaksi->saldo = $saldo;
        $transaksi->tipe = $request->tipe;
        $transaksi->save();

        return redirect('transaksi')->with('status', 'Berhasil Simpan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
