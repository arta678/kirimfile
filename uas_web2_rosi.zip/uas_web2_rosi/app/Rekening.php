<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rekening extends Model
{

	protected $fillable = ['saldo','id_nasabah'];
  	protected $primaryKey = 'id';
    public function nasabahs() {
    	return $this->belongsTo('App\Nasabah');
    }

    public function transaksis() {
    	return $this->hasMany('App\Transaksi');
    }
}
