@extends('sibasah.layout.layout')
@section('sidebar')
@section('transaksi',$active)
@endsection
{{-- @section('judul_navbar',$judul_navbar) --}}
@section('content')
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/transaksi">Home</a></li>
      {{-- <li class="breadcrumb-item"><a href="/nasabah">Nasabah</a></li> --}}
      <li class="breadcrumb-item active" aria-current="page">Transaksi</li>
    </ol>
  </nav>
  {{-- <div class="row"> --}}
  <div class="row">
    <div class="col-md-3">
      <div class="card card-user">
       <div class="card-header">
          <h6 class="card-title">Tambah Transaksi</h6>
          
          {{-- <p class="card-category">Tambah Nasabah</p> --}}
        </div>
       
        <div class="card-body">
          <form action="{{route('transaksi.store')}}" method="post">
            {{ csrf_field()}}
          <div class="from-group">
            <label>Nasabah</label>
            <select name="id_nasabah" class="form-control">
                    <option selected disabled>Pilih Nasabah</option> 
                    @foreach($nasabah as $n)
                      
                      <option value="{{$n -> id}}">[{{$n-> id}}]  - {{$n-> nama}}</option>
                    @endforeach
                  </select>
          </div>
          <div class="from-group">
            <label>Jenis Transaksi</label>
            <select class="form-control" name="tipe" required>
            <option selected disabled>Pilih jenis transaksi</option>
            <option value="1">Setor</option>
            <option value="0">Tarik</option>
          </select>
          </div>
          <div class="from-group">
            <label>Pilih Jenis Sampah</label>
            <select name="id_sampah" class="form-control">
                    <option selected disabled>Pilih Jenis Sampah</option> 
                    @foreach($sampah as $n) 
                      <option value="{{$n -> id}}">[{{$n-> id}}]  - {{$n-> jenis_sampah}}</option>
                    @endforeach
                  </select>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Harga/Kg</label>
                    {{-- @foreach($sampah as $n)  --}}
                     <input type="number" class="form-control" id="exampleInputPassword1" name="harga" value="{{$n->harga}}" readonly>
                    {{-- @endforeach --}}
            
            
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Berat Sampah</label>
            <input type="number" class="form-control" id="exampleInputPassword1" name="berat_sampah">
            
          </div>

          <button type="submit" class="btn btn-primary" name="btnSimpan" value="Simpan">Simpan</button>
          <button type="reset" class="btn btn-warning" name="btnSimpan" value="Ulang">Ulang</button>
        </form> 
        </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card card-user">
        <div class="card-body">
          @if (session('status'))
            <div class="alert alert-success alert-dismissible fade show my-3" role="alert">
              <strong>{{session('status')}}</strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          @endif
          @if (session('status_h'))
            <div class="alert alert-danger alert-dismissible fade show my-3" role="alert">
              <strong>{{session('status_h')}}</strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          @endif  
          <br>
          <div class="table-responsive">
            <table class="table" id="tb_index" width="100%">
              <thead class=" text-primary">
                {{-- <th>NO</th> --}}
                <th>Tanggal</th>
                {{-- <th>ID</th> --}}
                <th>Nasabah</th>
                <th>Sampah</th>
                <th>Berat</th>
                <th>Saldo</th>
                {{-- <th colspan="2" class="text-center">Aksi</th> --}}
              </thead>
              <tbody>

                @foreach($transaksi as $no=>$b)
                  {{-- <th>{{$no+1}}</th> --}}
                  <tr>
                    <td>{{$b->created_at->format('d M Y')}}</td>
                    {{-- <td>{{$b->id}}</td> --}}
                    <td>{{$b->nasabahs->nama}}</td>
                    <td>{{$b->sampahs->jenis_sampah}}</td>
                    <td>{{$b->berat_sampah}}</td>
                    <td>{{$b->saldo}}</td>
                    
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection