@extends('sibasah.layout.layout')
@section('sidebar')
@section('tabungan',$active)
@endsection
{{-- @section('judul_navbar',$judul_navbar) --}}
@section('content')
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/sampah">Home</a></li>
      {{-- <li class="breadcrumb-item"><a href="/nasabah">Nasabah</a></li> --}}
      <li class="breadcrumb-item active" aria-current="page">Sampah</li>
    </ol>
  </nav>
  {{-- <div class="row"> --}}
  <div class="row">
    <div class="col-md-12">
      <div class="card card-user">
        <div class="card-body">
          @if (session('status'))
            <div class="alert alert-success alert-dismissible fade show my-3" role="alert">
              <strong>{{session('status')}}</strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          @endif
          @if (session('status_h'))
            <div class="alert alert-danger alert-dismissible fade show my-3" role="alert">
              <strong>{{session('status_h')}}</strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          @endif  
          <br>
          <div class="table-responsive">
            <table class="table" id="tb_index" width="100%">
              <thead class=" text-primary">
                <th>No</th>
                <th>Nama</th>
                <th>Total Saldo</th>
              </thead>
              <tbody>
                @foreach($tabungan as $no=>$b)
                  <tr>
                    <td>{{$b->created_at}}</td>
                    <td>{{$b->id}}</td>
                    <td>{{$b->id_nasabah}}</td>
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection