 <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
          <h5>TUGAS WEB 2 </h5>
          </div>
        </div>
      </nav>