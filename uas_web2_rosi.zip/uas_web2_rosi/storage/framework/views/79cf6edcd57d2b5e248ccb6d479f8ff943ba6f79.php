<?php $__env->startSection('sidebar'); ?>
<?php $__env->startSection('sampah',$active); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/sampah">Home</a></li>
      <li class="breadcrumb-item"><a href="/sampah">Data Sampah</a></li>
      <li class="breadcrumb-item active" aria-current="page">Edit</li>
    </ol>
  </nav>
  <div class="row">
    <div class="col-md-4">
      <div class="card card-user">
       <div class="card-header">
          <h6 class="card-title">Tambah Sampah</h6>
          
        </div>
        <div class="card-body">
          <form action="<?php echo e(route('sampah.update',$sampah->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <div class="form-group my-1">
              <label class="col-form-label">ID</label>
              <input type="text" class="form-control" name="id" value="<?php echo e($sampah->id); ?>" disabled>
            </div>
            <div class="form-group my-1" >
              <label class="col-form-label">Jenis Sampah</label>
              <input type="text" class="form-control" id="exampleInputPassword1" name="jenis_sampah" value="<?php echo e($sampah->jenis_sampah); ?>">
              <?php if($errors->any()): ?>
                <small class="text-danger">
                  <?php $__currentLoopData = $errors->get('jenis_sampah'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </small>
              <?php endif; ?>
            </div>
            <div class="form-group my-1">
              <label class="col-form-label">Harga</label>
              <input type="text" class="form-control" name="harga" value="<?php echo e($sampah->harga); ?>">
              <?php if($errors->any()): ?>
                <small class="text-danger">
                  <?php $__currentLoopData = $errors->get('harga'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </small>
              <?php endif; ?>
            </div>
            <div class="text-right">
              <button type="submit" class="btn btn-danger" name="btnSimpan" value="Simpan">Update</button>
              <a href="<?php echo e(url('sampah')); ?>" class="btn btn-secondary">Batal</a>
            </div>
          </form> 
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sibasah.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>