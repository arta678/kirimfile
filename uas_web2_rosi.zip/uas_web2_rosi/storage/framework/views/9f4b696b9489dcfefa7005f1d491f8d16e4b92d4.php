<?php $__env->startSection('sidebar'); ?>
<?php $__env->startSection('transaksi',$active); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/transaksi">Home</a></li>
      
      <li class="breadcrumb-item active" aria-current="page">Transaksi</li>
    </ol>
  </nav>
  
  <div class="row">
    <div class="col-md-3">
      <div class="card card-user">
       <div class="card-header">
          <h6 class="card-title">Tambah Transaksi</h6>
          
          
        </div>
       
        <div class="card-body">
          <form action="<?php echo e(route('transaksi.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

          <div class="from-group">
            <label>Nasabah</label>
            <select name="id_nasabah" class="form-control">
                    <option selected disabled>Pilih Nasabah</option> 
                    <?php $__currentLoopData = $nasabah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <option value="<?php echo e($n -> id); ?>">[<?php echo e($n-> id); ?>]  - <?php echo e($n-> nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
          </div>
          <div class="from-group">
            <label>Jenis Transaksi</label>
            <select class="form-control" name="tipe" required>
            <option selected disabled>Pilih jenis transaksi</option>
            <option value="1">Setor</option>
            <option value="0">Tarik</option>
          </select>
          </div>
          <div class="from-group">
            <label>Pilih Jenis Sampah</label>
            <select name="id_sampah" class="form-control">
                    <option selected disabled>Pilih Jenis Sampah</option> 
                    <?php $__currentLoopData = $sampah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                      <option value="<?php echo e($n -> id); ?>">[<?php echo e($n-> id); ?>]  - <?php echo e($n-> jenis_sampah); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Harga/Kg</label>
                    
                     <input type="number" class="form-control" id="exampleInputPassword1" name="harga" value="<?php echo e($n->harga); ?>" readonly>
                    
            
            
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Berat Sampah</label>
            <input type="number" class="form-control" id="exampleInputPassword1" name="berat_sampah">
            
          </div>

          <button type="submit" class="btn btn-primary" name="btnSimpan" value="Simpan">Simpan</button>
          <button type="reset" class="btn btn-warning" name="btnSimpan" value="Ulang">Ulang</button>
        </form> 
        </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card card-user">
        <div class="card-body">
          <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show my-3" role="alert">
              <strong><?php echo e(session('status')); ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <?php if(session('status_h')): ?>
            <div class="alert alert-danger alert-dismissible fade show my-3" role="alert">
              <strong><?php echo e(session('status_h')); ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>  
          <br>
          <div class="table-responsive">
            <table class="table" id="tb_index" width="100%">
              <thead class=" text-primary">
                
                <th>Tanggal</th>
                
                <th>Nasabah</th>
                <th>Sampah</th>
                <th>Berat</th>
                <th>Saldo</th>
                
              </thead>
              <tbody>

                <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <tr>
                    <td><?php echo e($b->created_at->format('d M Y')); ?></td>
                    
                    <td><?php echo e($b->nasabahs->nama); ?></td>
                    <td><?php echo e($b->sampahs->jenis_sampah); ?></td>
                    <td><?php echo e($b->berat_sampah); ?></td>
                    <td><?php echo e($b->saldo); ?></td>
                    
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sibasah.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>