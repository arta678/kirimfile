<?php $__env->startSection('sidebar'); ?>
<?php $__env->startSection('sampah',$active); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/sampah">Home</a></li>
      
      <li class="breadcrumb-item active" aria-current="page">Sampah</li>
    </ol>
  </nav>
  
  <div class="row">
   
    <div class="col-md-4">
      <div class="card card-user">
       <div class="card-header">
          <h6 class="card-title">Tambah Sampah</h6>
          
          
        </div>
       
        <div class="card-body">
          <form action="<?php echo e(route('sampah.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

          
          <div class="form-group" >
            <label class="col-form-label">Jenis Sampah</label>
            <input type="text" class="form-control" name="jenis_sampah" placeholder="gelas aqua, kardus, dll">
            <?php if($errors->any()): ?>
              <small class="text-danger">
                <?php $__currentLoopData = $errors->get('jenis_sampah'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </small>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label class="col-form-label">Harga</label>
            <input type="number" class="form-control" name="harga">
            <?php if($errors->any()): ?>
              <small class="text-danger">
                <?php $__currentLoopData = $errors->get('harga'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </small>
            <?php endif; ?>
          </div>
          <button type="submit" class="btn btn-primary" name="btnSimpan" value="Simpan">Simpan</button>
          <button type="reset" class="btn btn-warning" name="btnSimpan" value="Ulang">Ulang</button>
        </form> 
        </div>
      </div>
    </div>
    <div class="col-md-8">
      <div class="card card-user">
        <div class="card-body">
          <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show my-3" role="alert">
              <strong><?php echo e(session('status')); ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <?php if(session('status_h')): ?>
            <div class="alert alert-danger alert-dismissible fade show my-3" role="alert">
              <strong><?php echo e(session('status_h')); ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>  
          <br>
          <div class="table-responsive">
            <table class="table" id="tb_index" width="100%">
              <thead class=" text-primary">
                
                <th>ID</th>
                <th>Jenis Sampah</th>
                <th>Harga</th>
                <th colspan="2" class="text-center">Aksi</th>
              </thead>
              <tbody>
                <?php $__currentLoopData = $sampah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <tr>
                    <td><?php echo e($b->id); ?></td>
                    <td><?php echo e($b->jenis_sampah); ?></td>
                    <td><?php echo e($b->harga); ?></td>
                    <td>
                      <a href="<?php echo e(route('sampah.edit',$b->id)); ?>" class="btn btn-primary">U</a>
                    </td>
                    <td>
                      <form action="<?php echo e(route('sampah.destroy', $b->id)); ?>" method="post" class="btn-delete">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button class="btn btn-danger" type="submit">H</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('perpus.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>