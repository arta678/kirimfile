<?php $__env->startSection('sidebar'); ?>
<?php $__env->startSection('buku',$active); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="margin-top: 80px;">
        <nav aria-label="breadcrumb" >
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/nasabah">Home</a></li>
            
            <li class="breadcrumb-item active" aria-current="page">Nasabah</li>
          </ol>
        </nav>
        
        <div class="row">
         
          <div class="col-md-4">
            <div class="card card-user">
             <div class="card-header">
                <h6 class="card-title">Tambah Nasabah</h6>
                
                
              </div>
             
              <div class="card-body">
                <form action="<?php echo e(route('nasabah.store')); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="exampleInputPassword1">ID</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="id" >
                </div>
                <div class="form-group" >
                  <label for="exampleInputPassword1">Nama</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="nama" >
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Hp</label>
                  <input type="text" class="form-control" id="exampleInputPassword1" name="hp">
                </div>
                <div class="form-group">
                  <label for="exampleFormControlTextarea1">Alamat</label>
                  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="alamat"></textarea>
                </div>
                
               
                <button type="submit" class="btn btn-primary" name="btnSimpan" value="Simpan">Simpan</button>
              </form> 
              </div>
            </div>
          </div>
          <div class="col-md-8">
            <div class="card card-user">
              <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?> 
                <br>
                <div class="table-responsive">

                    
                  <table class="table">
                    <thead class=" text-primary">
                    
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Telepon</th>
                    <th>Alamat</th>
                    <th colspan="2" class="text-center">Aksi</th>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $nasabah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <th><?php echo e($b->id); ?></th>
                      <th><?php echo e($b->nama); ?></th>
                      <th><?php echo e($b->hp); ?></th>
                      <th><?php echo e($b->alamat); ?></th>
                      <th>
                        <a href="nasabah/<?php echo e($b->id); ?>/edit"><button class="btn btn-warning" type="submit">U</button></a>
                      </th>
                      <th>
                        <form action="<?php echo e(action('Con_nasabah@destroy', $b['id_buku'])); ?>" method="post">
                              <?php echo e(csrf_field()); ?>

                              <input name="_method" type="hidden" value="DELETE">
                              <button class="btn btn-danger" type="submit">H</button>
                            </form>
                      </th>
                    </tbody>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('perpus.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>