<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rekening;
class Con_tabungan extends Controller
{
    public function index()
    {
    	$active = "active";
        // return view('sibasah.tabungan.tabungan',compact('tabungan','title','judul_navbar','active'));
        $rekening = Rekening::all();
        return view('sibasah.tabungan.tabungan', compact('rekening','active'));
    }
    // public function getTotalSaldo() {
    // 	$rekening = Rekening::all();
    //     return view('saving.viewAll', compact('rekening'));
    // }
}
