<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;
class Rekening extends Model
{

	protected $fillable = ['saldo','id_nasabah'];
  	protected $primaryKey = 'id';
    public function nasabahs() {
    	return $this->belongsTo('App\Nasabah','id_nasabah');
    }

    public function transaksis() {
    	return $this->hasMany('App\Transaksi');
    }

    public function getTotalSaldo($id)
    {
    	$totalSaldo = DB::table('transaksis')->where('id_nasabah', $id)->sum('saldo');
        return $totalSaldo;
    }
}
