<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
	protected $fillable = ['id_nasabah','id_sampah','id_rekening','berat_sampah','saldo','tipe'];
    protected $primaryKey = 'id';

    
    public function nasabahs() {
    	return $this->belongsTo('App\Nasabah', 'id_nasabah');
    }

    public function rekenings() {
    	return $this->belongsTo('App\Rekening', 'id_rekening');
    }
    public function sampahs() {
    	return $this->belongsTo('App\Sampah', 'id_sampah');
    }
}
