<?php $__env->startSection('sidebar'); ?>
<?php $__env->startSection('nasabah',$active); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/nasabah">Home</a></li>
      
      <li class="breadcrumb-item active" aria-current="page">Nasabah</li>
    </ol>
  </nav>
  
  <div class="row">
    <div class="col-md-3">
      <div class="card card-user">
       <div class="card-header">
          <h6 class="card-title text-center">Tambah Nasabah</h6>
        </div>
       
        <div class="card-body">
          <form action="<?php echo e(route('nasabah.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

          
          <div class="form-group" >
            <label>Nama</label>
            <input type="text" class="form-control" name="nama" >
            <?php if($errors->any()): ?>
              <small class="text-danger">
                <?php $__currentLoopData = $errors->get('nama'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </small>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Hp</label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="hp">
            <?php if($errors->any()): ?>
              <small class="text-danger">
                <?php $__currentLoopData = $errors->get('hp'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </small>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label for="exampleFormControlTextarea1">Alamat</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="alamat"></textarea>
            <?php if($errors->any()): ?>
              <small class="text-danger">
                <?php $__currentLoopData = $errors->get('alamat'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </small>
            <?php endif; ?>
          </div>
          <button type="submit" class="btn btn-primary" name="btnSimpan" value="Simpan">Simpan</button>
          <button type="reset" class="btn btn-warning" name="btnSimpan" value="Ulang">Ulang</button>
        </form> 
        </div>
      </div>
    </div>
    <div class="col-md-9">
      <div class="card card-user">

        <div class="card-body">
          <h6 class="card-title text-center">Data Nasabah</h6>
          <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show my-3" role="alert">
              <strong><?php echo e(session('status')); ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
          <?php if(session('status_h')): ?>
            <div class="alert alert-danger alert-dismissible fade show my-3" role="alert">
              <strong><?php echo e(session('status_h')); ?></strong>
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>  
          <br>

          
          <div class="table-responsive">
            <table class="table" id="tb_index" width="100%">
              <thead class=" text-primary">
                
                <th>ID</th>
                <th>Nama</th>
                <th>Telepon</th>
                <th>Alamat</th>
                <th colspan="2" class="text-center">Aksi</th>
              </thead>
              <tbody>

                <?php $__currentLoopData = $nasabah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <tr>
                    <td><?php echo e($b->id); ?></td>
                    <td><?php echo e($b->nama); ?></td>
                    <td><?php echo e($b->hp); ?></td>
                    <td><?php echo e($b->alamat); ?></td>
                    <td>
                      <a href="<?php echo e(route('nasabah.edit',$b->id)); ?>" class="btn btn-primary">U</a>
                    </td>
                    <td>
                      <form action="<?php echo e(route('nasabah.destroy', $b->id)); ?>" method="post" class="btn-delete">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button class="btn btn-danger" type="submit">H</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sibasah.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>