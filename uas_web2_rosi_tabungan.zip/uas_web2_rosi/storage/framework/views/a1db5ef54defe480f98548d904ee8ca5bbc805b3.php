<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    <?php echo $__env->yieldContent('title'); ?>
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="<?php echo e(asset('paper/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('paper/assets/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('paper/assets/css/paper-dashboard.css?v=2.0.0')); ?>" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  
</head>

<body class="">
  <div class="wrapper ">
   
    <?php echo $__env->make('perpus.layout.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main-panel">
      <!-- Navbar -->

      <?php echo $__env->make('perpus.layout.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->yieldContent('content'); ?>
      <?php echo $__env->make('perpus.layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="<?php echo e(asset('paper/assets/js/core/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('paper/assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('paper/assets/js/core/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('paper/assets/js/plugins/perfect-scrollbar.jquery.min.js')); ?>"></script>
  
  
  <!--  Google Maps Plugin    -->

  <!-- Chart JS -->
  <script src="<?php echo e(asset('paper/assets/js/plugins/chartjs.min.js')); ?>"></script>
  <!--  Notifications Plugin    -->
  <script src="<?php echo e(asset('paper/assets/js/plugins/bootstrap-notify.js')); ?>"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo e(asset('paper/assets/js/paper-dashboard.min.js?v=2.0.0')); ?>" type="text/javascript"></script>
  <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  
  <script src="<?php echo e(asset('paper/assets/demo/demo.js')); ?>"></script>
    <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/assets-for-demo/js/demo.js
      demo.initChartsPages();
    });
  </script>
  
  <script>
    $(".btn-delete").on("submit", function(){
      return confirm("Anda yakin ingin menghapus data?");
    });
  </script>
</body>

</html>
