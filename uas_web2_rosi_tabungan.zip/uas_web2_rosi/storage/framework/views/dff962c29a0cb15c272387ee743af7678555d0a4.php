<?php $__env->startSection('sidebar'); ?>
<?php $__env->startSection('tabungan',$active); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/nasabah">Home</a></li>
      
      <li class="breadcrumb-item active" aria-current="page">Nasabah</li>
    </ol>
  </nav>
  
  <div class="row">
    
    <div class="col-md-12">
      <div class="card card-user">
        <div class="card-body">
          <br>
          <div class="table-responsive">
            <table class="table" id="tb_index" width="100%">
              <thead class=" text-primary">
                
                <th>ID</th>
                <th>Nama</th>
                <th>Total Saldo</th>
              </thead>
              <tbody>

                <?php $__currentLoopData = $rekening; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <tr>
                    <td><?php echo e($b->id); ?></td>
                    <td><?php echo e($b->nasabahs->nama); ?></td>
                    <td>Rp. <?php echo e($b->getTotalSaldo($b->id)); ?></td>
                    
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sibasah.layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>