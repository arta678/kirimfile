@extends('sibasah.layout.layout')
@section('sidebar')
@section('tabungan',$active)
@endsection
{{-- @section('judul_navbar',$judul_navbar) --}}
@section('content')
<div class="content" style="margin-top: 80px;">
  <nav aria-label="breadcrumb" >
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="/nasabah">Home</a></li>
      {{-- <li class="breadcrumb-item"><a href="/nasabah">Nasabah</a></li> --}}
      <li class="breadcrumb-item active" aria-current="page">Nasabah</li>
    </ol>
  </nav>
  {{-- <div class="row"> --}}
  <div class="row">
    
    <div class="col-md-12">
      <div class="card card-user">
        <div class="card-body">
          <br>
          <div class="table-responsive">
            <table class="table" id="tb_index" width="100%">
              <thead class=" text-primary">
                {{-- <th>NO</th> --}}
                <th>ID</th>
                <th>Nama</th>
                <th>Total Saldo</th>
              </thead>
              <tbody>

                @foreach($rekening as $no=>$b)
                  {{-- <th>{{$no+1}}</th> --}}
                  <tr>
                    <td>{{$b->id}}</td>
                    <td>{{$b->nasabahs->nama}}</td>
                    <td>Rp. {{$b->getTotalSaldo($b->id)}}</td>
                    
                  </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection